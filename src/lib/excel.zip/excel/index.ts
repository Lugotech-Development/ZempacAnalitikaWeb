// Public surface of the Excel export module. Report pages import the builder
// types + the per-report export helpers from here.

export {
  downloadReport,
  downloadReceipt,
  type ReportColumn,
  type ReportConfig,
  type ReportMetaItem,
  type ReceiptLine,
  type ReceiptConfig
} from './builder';

export type { ColumnType } from './theme';

/** Strip characters that are illegal in filenames on common operating systems. */
export function fileNameSafe(s: string): string {
  return s.replace(/[\\/:*?"<>|]/g, '-').replace(/\s+/g, ' ').trim();
}
