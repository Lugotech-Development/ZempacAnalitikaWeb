import { downloadReport, type ReportColumn, type ReportMetaItem } from '../builder';
import type { RptVenta, VentaSucursalSummary } from '@/lib/types';

const SUCURSAL_COLUMNS: ReportColumn[] = [
  { header: 'Sucursal', key: 'sucursal', type: 'int', width: 10, align: 'center' },
  { header: 'Almacén', key: 'almacen', type: 'text', width: 32 },
  { header: 'Total Vendido', key: 'totalVendido', type: 'money', total: true },
  { header: 'Ticket Promedio', key: 'ticket', type: 'money' },
  { header: 'Subtotal', key: 'subtotal', type: 'money', total: true },
  { header: 'Descuento', key: 'descuento', type: 'money', total: true },
  { header: 'Impuesto', key: 'impuesto', type: 'money', total: true },
  { header: 'Total Costo', key: 'costo', type: 'money', total: true },
  { header: 'Margen %', key: 'margen', type: 'percent' },
  { header: '% Relativo', key: 'relativo', type: 'percent' },
  { header: 'Facturas', key: 'facturas', type: 'int', total: true }
];

const DIARIO_COLUMNS: ReportColumn[] = [
  { header: 'Fecha', key: 'fecha', type: 'date' },
  { header: 'Total Vendido', key: 'totalVendido', type: 'money', total: true },
  { header: 'Ticket Promedio', key: 'ticket', type: 'money' },
  { header: 'Subtotal', key: 'subtotal', type: 'money', total: true },
  { header: 'Descuento', key: 'descuento', type: 'money', total: true },
  { header: 'Impuesto', key: 'impuesto', type: 'money', total: true },
  { header: 'Total Costo', key: 'costo', type: 'money', total: true },
  { header: 'Margen %', key: 'margen', type: 'percent' },
  { header: '% Relativo', key: 'relativo', type: 'percent' },
  { header: 'Facturas', key: 'facturas', type: 'int', total: true }
];

export function exportVentasSucursales(summaries: VentaSucursalSummary[], meta?: ReportMetaItem[]): Promise<void> {
  return downloadReport({
    title: 'Ventas por Sucursal',
    subtitle: 'Resumen de ventas de los últimos 30 días por sucursal',
    fileName: 'ventas-por-sucursal',
    sheetName: 'Ventas por Sucursal',
    meta,
    columns: SUCURSAL_COLUMNS,
    rows: summaries.map(s => ({
      sucursal: s.sucursal,
      almacen: s.almacenNombre || `Sucursal ${s.sucursal}`,
      totalVendido: s.totalVendido,
      ticket: s.ticketPromedio,
      subtotal: s.subTotal,
      descuento: s.montoDescuento,
      impuesto: s.montoImpuesto,
      costo: s.totalCosto,
      margen: s.porcMargenEstimado,
      relativo: s.porcentajeRelativo,
      facturas: s.cantidadFacturas
    }))
  });
}

export function exportVentasDiarias(items: RptVenta[], fileNameSlug: string, meta?: ReportMetaItem[]): Promise<void> {
  return downloadReport({
    title: 'Ventas Diarias',
    subtitle: 'Detalle diario de ventas de la sucursal',
    fileName: `ventas-${fileNameSlug}`,
    sheetName: 'Ventas Diarias',
    meta,
    columns: DIARIO_COLUMNS,
    rows: items.map(item => ({
      fecha: item.fecha ?? '',
      totalVendido: item.totalVendido ?? 0,
      ticket: item.ticketPromedio ?? 0,
      subtotal: item.subTotal ?? 0,
      descuento: item.montoDescuento ?? 0,
      impuesto: item.montoImpuesto ?? 0,
      costo: item.totalCosto ?? 0,
      margen: item.porcMargenEstimado ?? 0,
      relativo: item.porcentajeRelativo ?? 0,
      facturas: item.cantidadFacturas ?? 0
    }))
  });
}
