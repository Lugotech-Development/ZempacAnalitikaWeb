import { downloadReport, type ReportColumn, type ReportMetaItem } from '../builder';
import type { RptVentaFacturador } from '@/lib/types';

const COLUMNS: ReportColumn[] = [
  { header: 'Facturador', key: 'facturador', type: 'text', width: 32 },
  { header: 'Cédula', key: 'cedula', type: 'text', width: 18 },
  { header: 'Sucursal', key: 'sucursal', type: 'text', width: 22 },
  { header: 'Facturas', key: 'facturas', type: 'int', total: true },
  { header: 'Total Venta', key: 'total', type: 'money', total: true },
  { header: '% del Total', key: 'pct', type: 'percent' }
];

export function exportVentasFacturador(rows: RptVentaFacturador[], meta?: ReportMetaItem[]): Promise<void> {
  const grandTotal = rows.reduce((s, r) => s + (r.totalVenta ?? 0), 0);
  return downloadReport({
    title: 'Ventas por Facturador',
    subtitle: 'Ventas agrupadas por colaborador facturador',
    fileName: 'ventas-por-facturador',
    sheetName: 'Por Facturador',
    meta,
    columns: COLUMNS,
    rows: rows.map(r => ({
      facturador: r.facturador ?? '',
      cedula: r.cedula ?? '',
      sucursal: r.sucursal ?? '',
      facturas: r.cantidadFacturas ?? 0,
      total: r.totalVenta ?? 0,
      pct: grandTotal > 0 && r.totalVenta != null ? (r.totalVenta / grandTotal) * 100 : 0
    }))
  });
}
