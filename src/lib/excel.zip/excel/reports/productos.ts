import { downloadReport, type ReportColumn, type ReportMetaItem } from '../builder';
import type { RptProductoMasVendido } from '@/lib/types';

const COLUMNS: ReportColumn[] = [
  { header: '#', key: 'rank', type: 'int', width: 6, align: 'center' },
  { header: 'SKU', key: 'sku', type: 'text', width: 16 },
  { header: 'Producto', key: 'producto', type: 'text', width: 40 },
  { header: 'Cantidad', key: 'cantidad', type: 'int', total: true },
  { header: 'Total Vendido', key: 'total', type: 'money', total: true },
  { header: 'Costo Estimado', key: 'costo', type: 'money', total: true },
  { header: 'Margen Estimado', key: 'margen', type: 'money', total: true },
  { header: 'Margen %', key: 'margenPct', type: 'percent' },
  { header: 'Facturas', key: 'facturas', type: 'int', total: true }
];

export function exportProductosMasVendidos(productos: RptProductoMasVendido[], meta?: ReportMetaItem[]): Promise<void> {
  return downloadReport({
    title: 'Productos Más Vendidos',
    subtitle: 'Ranking del período con margen, facturas y costo',
    fileName: 'productos-mas-vendidos',
    sheetName: 'Más Vendidos',
    meta,
    columns: COLUMNS,
    rows: productos.map((p, i) => {
      const total = p.totalVendido ?? 0;
      const margen = p.margenEstimado ?? 0;
      return {
        rank: i + 1,
        sku: p.producto ?? '',
        producto: p.productoNombre ?? '',
        cantidad: p.cantidadVendida ?? 0,
        total,
        costo: p.costoEstimado ?? 0,
        margen,
        margenPct: total > 0 ? (margen / total) * 100 : 0,
        facturas: p.cantidadFacturas ?? 0
      };
    })
  });
}
