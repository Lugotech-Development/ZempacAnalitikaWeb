import { downloadReport, type ReportColumn, type ReportMetaItem } from '../builder';
import type { RptProductoNegativo } from '@/lib/types';

const COLUMNS: ReportColumn[] = [
  { header: 'Código', key: 'codigo', type: 'text', width: 14 },
  { header: 'Producto', key: 'producto', type: 'text', width: 44 },
  { header: 'Almacén', key: 'almacen', type: 'int', width: 12, align: 'center' },
  { header: 'Existencia', key: 'existencia', type: 'decimal', total: true }
];

export function exportProductosNegativos(rows: RptProductoNegativo[], meta?: ReportMetaItem[]): Promise<void> {
  return downloadReport({
    title: 'Productos Negativos',
    subtitle: 'Productos con existencia negativa por sucursal',
    fileName: 'productos-negativos',
    sheetName: 'Productos Negativos',
    meta,
    columns: COLUMNS,
    rows: rows.map(r => ({
      codigo: r.docNum ?? '',
      producto: r.nombre ?? '',
      almacen: r.almacen ?? '',
      existencia: r.existencia ?? 0
    }))
  });
}
