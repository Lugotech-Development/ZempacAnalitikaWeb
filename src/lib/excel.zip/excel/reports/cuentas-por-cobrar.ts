import { downloadReport, type ReportColumn, type ReportMetaItem } from '../builder';
import { fmtInt, fmtMoney } from '@/lib/format';
import type { RptCxcResumen, RptCxcTopCliente } from '@/lib/types';

const COLUMNS: ReportColumn[] = [
  { header: '#', key: 'rank', type: 'int', width: 6, align: 'center' },
  { header: 'Código', key: 'codigo', type: 'text', width: 16 },
  { header: 'Cliente', key: 'cliente', type: 'text', width: 40 },
  { header: 'Saldo Total', key: 'saldo', type: 'money', total: true },
  { header: 'Corriente', key: 'corriente', type: 'money', total: true },
  { header: 'Vencido', key: 'vencido', type: 'money', total: true },
  { header: 'Facturas', key: 'facturas', type: 'int', total: true },
  { header: 'Días Máx. Atraso', key: 'dias', type: 'int', width: 16 },
  { header: 'Categoría', key: 'categoria', type: 'text', width: 18 },
  { header: 'Última Factura', key: 'ultima', type: 'date' }
];

export function exportCuentasPorCobrar(clientes: RptCxcTopCliente[], resumen: RptCxcResumen): Promise<void> {
  // The header carries the whole-portfolio figures (the website's headline),
  // while the table lists the top clients. When that's a subset we flag it and
  // label the table subtotal accordingly, so the two totals never look wrong.
  const isSubset = resumen.clientesConSaldo > clientes.length;

  const meta: ReportMetaItem[] = [
    { label: 'Saldo total cartera', value: fmtMoney(resumen.saldoTotal) },
    { label: 'Clientes con saldo', value: fmtInt(resumen.clientesConSaldo) }
  ];
  if (isSubset) meta.push({ label: 'Mostrando', value: `Top ${clientes.length}` });

  return downloadReport({
    title: 'Cuentas por Cobrar',
    subtitle: 'Clientes con saldo pendiente y antigüedad',
    fileName: 'cuentas-por-cobrar',
    sheetName: 'Cuentas por Cobrar',
    meta,
    totalsLabel: isSubset ? `TOTAL (TOP ${clientes.length})` : 'TOTAL',
    columns: COLUMNS,
    rows: clientes.map((c, i) => ({
      rank: i + 1,
      codigo: c.clienteCodigo ?? '',
      cliente: c.clienteNombre ?? '',
      saldo: c.saldoTotal,
      corriente: c.corriente,
      vencido: c.vencido,
      facturas: c.totalFacturas,
      dias: c.diasMaxAtraso,
      categoria: c.categoria ?? '',
      ultima: c.ultimaFacturaFecha ?? ''
    }))
  });
}
