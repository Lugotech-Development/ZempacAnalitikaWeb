import { downloadReport, type ReportColumn, type ReportMetaItem } from '../builder';
import type { RptVentaProductoMarca } from '@/lib/types';

const COLUMNS: ReportColumn[] = [
  { header: 'Marca', key: 'marca', type: 'text', width: 22 },
  { header: 'Sucursal', key: 'sucursal', type: 'text', width: 20 },
  { header: 'Producto', key: 'producto', type: 'text', width: 36 },
  { header: 'Código', key: 'codigo', type: 'text', width: 14 },
  { header: 'Cantidad', key: 'cantidad', type: 'int', total: true },
  { header: 'Total', key: 'total', type: 'money', total: true }
];

export function exportVentasProductoMarca(rows: RptVentaProductoMarca[], meta?: ReportMetaItem[]): Promise<void> {
  return downloadReport({
    title: 'Ventas por Marca',
    subtitle: 'Productos vendidos agrupados por marca en el período',
    fileName: 'ventas-por-marca',
    sheetName: 'Ventas por Marca',
    meta,
    columns: COLUMNS,
    rows: rows.map(r => ({
      marca: r.marca ?? '',
      sucursal: r.sucursal ?? '',
      producto: r.producto ?? '',
      codigo: r.codigoProducto ?? '',
      cantidad: r.cantidad ?? 0,
      total: r.totalVenta ?? 0
    }))
  });
}
