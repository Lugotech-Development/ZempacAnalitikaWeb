import { downloadReport, type ReportColumn, type ReportMetaItem } from '../builder';
import type { DevolucionSucursalSummary, RptDevolucion } from '@/lib/types';

const SUCURSAL_COLUMNS: ReportColumn[] = [
  { header: 'Sucursal', key: 'sucursal', type: 'int', width: 10, align: 'center' },
  { header: 'Almacén', key: 'almacen', type: 'text', width: 32 },
  { header: 'Total Devuelto', key: 'total', type: 'money', total: true },
  { header: 'Pendiente', key: 'pendiente', type: 'money', total: true },
  { header: 'Crédito', key: 'credito', type: 'money', total: true },
  { header: 'Subtotal', key: 'subtotal', type: 'money', total: true },
  { header: 'Descuento', key: 'descuento', type: 'money', total: true },
  { header: 'Impuesto', key: 'impuesto', type: 'money', total: true },
  { header: 'Cantidad', key: 'cantidad', type: 'int', total: true },
  { header: 'Motivos', key: 'motivos', type: 'text', width: 40 }
];

const DIARIO_COLUMNS: ReportColumn[] = [
  { header: 'Fecha', key: 'fecha', type: 'date' },
  { header: 'Total Devuelto', key: 'total', type: 'money', total: true },
  { header: 'Pendiente', key: 'pendiente', type: 'money', total: true },
  { header: 'Crédito', key: 'credito', type: 'money', total: true },
  { header: 'Subtotal', key: 'subtotal', type: 'money', total: true },
  { header: 'Descuento', key: 'descuento', type: 'money', total: true },
  { header: 'Cantidad', key: 'cantidad', type: 'int', total: true },
  { header: 'Motivo', key: 'motivo', type: 'text', width: 34 }
];

export function exportDevolucionesSucursales(summaries: DevolucionSucursalSummary[], meta?: ReportMetaItem[]): Promise<void> {
  return downloadReport({
    title: 'Devoluciones por Sucursal',
    subtitle: 'Resumen de devoluciones de los últimos 30 días por sucursal',
    fileName: 'devoluciones-por-sucursal',
    sheetName: 'Devoluciones',
    meta,
    columns: SUCURSAL_COLUMNS,
    rows: summaries.map(s => ({
      sucursal: s.sucursal,
      almacen: s.almacenNombre || `Sucursal ${s.sucursal}`,
      total: s.totalDevuelto,
      pendiente: s.totalNC,
      credito: s.totalCredito,
      subtotal: s.subTotalDevuelto,
      descuento: s.descuentoDevuelto,
      impuesto: s.impuestoDevuelto,
      cantidad: s.cantidadDevoluciones,
      motivos: s.motivos.join(', ')
    }))
  });
}

export function exportDevolucionesDiarias(items: RptDevolucion[], fileNameSlug: string, meta?: ReportMetaItem[]): Promise<void> {
  return downloadReport({
    title: 'Devoluciones Diarias',
    subtitle: 'Detalle diario de devoluciones de la sucursal',
    fileName: `devoluciones-${fileNameSlug}`,
    sheetName: 'Devoluciones Diarias',
    meta,
    columns: DIARIO_COLUMNS,
    rows: items.map(item => ({
      fecha: item.fecha ?? '',
      total: item.totalDevuelto ?? 0,
      pendiente: item.totalNC ?? 0,
      credito: item.totalCredito ?? 0,
      subtotal: item.subTotalDevuelto ?? 0,
      descuento: item.descuentoDevuelto ?? 0,
      cantidad: item.cantidadDevoluciones ?? 0,
      motivo: item.motivo ?? ''
    }))
  });
}
