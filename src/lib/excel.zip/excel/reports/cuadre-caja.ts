import { downloadReceipt, downloadReport, type ReceiptLine, type ReportColumn, type ReportMetaItem } from '../builder';
import {
  cuadreCleanDesc,
  cuadreIsDivider,
  cuadreIsSectionHeader,
  cuadreIsSpacer,
  cuadreIsSubItem,
  type RptCuadreCajaLinea,
  type RptProductoPorLote
} from '@/lib/types';

/** Classify a cuadre receipt line into the styled kind the receipt uses. */
function classify(l: RptCuadreCajaLinea): ReceiptLine['kind'] {
  if (cuadreIsSectionHeader(l)) return 'header';
  const upper = cuadreCleanDesc(l).toUpperCase();
  if (upper.includes('TOTAL') || upper.includes('DIFERENCIA') || upper === 'EFECTIVO EN CAJA') return 'total';
  if (cuadreIsSubItem(l)) return 'subitem';
  return 'item';
}

/** Flatten a cuadre receipt (general or lote-condensado) into styled lines. */
export function exportCuadreReceipt(
  lineas: RptCuadreCajaLinea[],
  opts: { title: string; subtitle?: string; sheetName: string; fileName: string; meta?: ReportMetaItem[] }
): Promise<void> {
  const lines: ReceiptLine[] = lineas
    .filter(l => !cuadreIsDivider(l) && !cuadreIsSpacer(l))
    .map(l => {
      const kind = classify(l);
      const valor = l.valor != null ? (l.signo === -1 ? -Math.abs(l.valor) : Math.abs(l.valor)) : null;
      return {
        descripcion: cuadreCleanDesc(l),
        cantidad: l.cantidad ?? null,
        valor: kind === 'header' ? null : valor,
        kind
      };
    });

  return downloadReceipt({
    title: opts.title,
    subtitle: opts.subtitle,
    sheetName: opts.sheetName,
    fileName: opts.fileName,
    meta: opts.meta,
    lines
  });
}

const PRODUCTO_COLUMNS: ReportColumn[] = [
  { header: 'Código', key: 'codigo', type: 'text', width: 16 },
  { header: 'Producto', key: 'producto', type: 'text', width: 46 },
  { header: 'Vendido', key: 'vendido', type: 'int', total: true }
];

export function exportCuadreProductos(
  rows: RptProductoPorLote[],
  opts: { fileName: string; meta?: ReportMetaItem[] }
): Promise<void> {
  return downloadReport({
    title: 'Cuadre de Caja · Productos por Lote',
    subtitle: 'Unidades vendidas por producto en el lote',
    fileName: opts.fileName,
    sheetName: 'Productos por lote',
    meta: opts.meta,
    columns: PRODUCTO_COLUMNS,
    rows: rows.map(p => ({
      codigo: p.codigo ?? '',
      producto: p.nombre ?? '',
      vendido: p.vendido ?? 0
    }))
  });
}
