// Premium report workbook builder. Every Zempac Analitika Excel export runs
// through here so they share one branded look — a "letterhead" header (logo +
// wordmark eyebrow → title → subtitle → meta strip), a light, website-style
// table header (uppercase muted labels under a primary accent rule), airy rows
// with horizontal-only separators, a brand-tinted totals row and a footer.
// Two entry points:
//   • downloadReport()  — a standard columnar table.
//   • downloadReceipt() — the Cuadre de Caja receipt (section headers, totals).
//
// Runs client-side only (uses Blob + <a download>); import from 'use client'
// modules.

import ExcelJS from 'exceljs';
import { ZEMPAC_LOGO_BASE64, ZEMPAC_LOGO_EXTENSION } from './logo';
import {
  BRAND,
  FONT,
  THIN_BORDER,
  defaultAlign,
  defaultWidth,
  numFmtFor,
  type ColumnType
} from './theme';

// ─── Public types ─────────────────────────────────────────────────────────

export interface ReportColumn {
  /** Column header shown in the styled header row. */
  header: string;
  /** Key read from each row object. */
  key: string;
  /** Drives number format + default alignment. Defaults to 'text'. */
  type?: ColumnType;
  /** Column width in characters. Defaults per type; grown to fit the header. */
  width?: number;
  /** Sum this column in the totals row (money/int/decimal/percent only). */
  total?: boolean;
  /** Override the default alignment for this column. */
  align?: 'left' | 'center' | 'right';
}

export interface ReportMetaItem {
  label: string;
  value: string;
}

export interface ReportConfig {
  title: string;
  subtitle?: string;
  /** File name; '.xlsx' appended if missing. */
  fileName: string;
  sheetName: string;
  columns: ReportColumn[];
  rows: Array<Record<string, unknown>>;
  /** Contextual strip under the title (period, sucursal, filters…). */
  meta?: ReportMetaItem[];
  /** Show a summed totals row. Default true when any column has `total`. */
  showTotals?: boolean;
  totalsLabel?: string;
  /** Header/accent color (ARGB). Defaults to brand primary. */
  accent?: string;
}

export type ReceiptLineKind = 'header' | 'item' | 'subitem' | 'total';

export interface ReceiptLine {
  descripcion: string;
  cantidad?: number | null;
  valor?: number | null;
  kind: ReceiptLineKind;
}

export interface ReceiptConfig {
  title: string;
  subtitle?: string;
  fileName: string;
  sheetName: string;
  meta?: ReportMetaItem[];
  lines: ReceiptLine[];
  accent?: string;
}

// ─── Shared helpers ─────────────────────────────────────────────────────────

function fill(argb: string): ExcelJS.Fill {
  return { type: 'pattern', pattern: 'solid', fgColor: { argb } };
}

function nowStamp(): string {
  return new Intl.DateTimeFormat('es-HN', { dateStyle: 'long', timeStyle: 'short' }).format(new Date());
}

/** Coerce a raw row value into the cell value ExcelJS should store. */
function cellValue(raw: unknown, type: ColumnType): string | number | Date | null {
  if (type === 'text') return raw == null ? '' : String(raw);
  if (type === 'date') {
    if (raw == null || raw === '') return '';
    if (raw instanceof Date) return raw;
    const d = new Date(String(raw));
    return Number.isNaN(d.getTime()) ? String(raw) : d;
  }
  // Numeric family.
  const n = typeof raw === 'number' ? raw : Number(raw);
  if (!Number.isFinite(n)) return 0;
  return type === 'percent' ? n / 100 : n; // percents arrive as 0–100, stored as ratio
}

/**
 * Letterhead: an embedded logo + wordmark eyebrow, the title, subtitle and a
 * one-line meta strip. Runs on every export so the top of the sheet is
 * identical everywhere. Leaves the cursor on the spacer row before the table.
 */
function addChrome(
  wb: ExcelJS.Workbook,
  ws: ExcelJS.Worksheet,
  opts: { title: string; subtitle?: string; meta?: ReportMetaItem[]; colCount: number; accent: string }
): void {
  const { title, subtitle, meta, colCount, accent } = opts;

  // Wordmark row — the logo floats over its left edge to form the lockup.
  const wm = ws.addRow([]);
  wm.height = 21;
  ws.mergeCells(wm.number, 1, wm.number, colCount);
  const wmCell = ws.getCell(wm.number, 1);
  wmCell.value = 'Zempac Analitika';
  wmCell.font = { name: FONT, size: 12, bold: true, color: { argb: accent } };
  wmCell.alignment = { vertical: 'middle', horizontal: 'left', indent: 4 };

  const imageId = wb.addImage({ base64: ZEMPAC_LOGO_BASE64, extension: ZEMPAC_LOGO_EXTENSION });
  ws.addImage(imageId, { tl: { col: 0.08, row: wm.number - 1 + 0.12 }, ext: { width: 22, height: 22 }, editAs: 'oneCell' });

  // Title.
  const tr = ws.addRow([]);
  tr.height = 30;
  ws.mergeCells(tr.number, 1, tr.number, colCount);
  const tCell = ws.getCell(tr.number, 1);
  tCell.value = title;
  tCell.font = { name: FONT, size: 20, bold: true, color: { argb: BRAND.ink } };
  tCell.alignment = { vertical: 'middle', horizontal: 'left' };

  // Subtitle.
  if (subtitle) {
    const sr = ws.addRow([]);
    sr.height = 17;
    ws.mergeCells(sr.number, 1, sr.number, colCount);
    const sCell = ws.getCell(sr.number, 1);
    sCell.value = subtitle;
    sCell.font = { name: FONT, size: 10.5, color: { argb: BRAND.inkVariant } };
    sCell.alignment = { vertical: 'middle', horizontal: 'left' };
  }

  // Meta strip — headline figures on one line: LABEL value · LABEL value.
  // Labels stay small + muted; values are larger, bold and brand-accented so
  // they read like the KPI numbers on the dashboard.
  if (meta && meta.length > 0) {
    ws.addRow([]).height = 4;
    const mr = ws.addRow([]);
    mr.height = 20;
    ws.mergeCells(mr.number, 1, mr.number, colCount);
    const segs: Array<{ font: Partial<ExcelJS.Font>; text: string }> = [];
    meta.forEach((m, i) => {
      if (i > 0) segs.push({ font: { name: FONT, size: 12, color: { argb: BRAND.outline } }, text: '          ' });
      segs.push({ font: { name: FONT, size: 9.5, bold: true, color: { argb: BRAND.outline } }, text: `${m.label.toUpperCase()}   ` });
      segs.push({ font: { name: FONT, size: 12.5, bold: true, color: { argb: accent } }, text: m.value });
    });
    ws.getCell(mr.number, 1).value = { richText: segs };
    ws.getCell(mr.number, 1).alignment = { vertical: 'middle', horizontal: 'left' };
  }

  ws.addRow([]).height = 10; // breathing room before the table
}

function addFooter(ws: ExcelJS.Worksheet, colCount: number): void {
  ws.addRow([]).height = 8;
  const fr = ws.addRow([]);
  ws.mergeCells(fr.number, 1, fr.number, colCount);
  const fc = ws.getCell(fr.number, 1);
  fc.value = `Documento generado automáticamente · Zempac Analitika · ${nowStamp()}`;
  fc.font = { name: FONT, size: 9, italic: true, color: { argb: BRAND.outline } };
  fc.alignment = { vertical: 'middle', horizontal: 'left' };
}

function newSheet(wb: ExcelJS.Workbook, sheetName: string): ExcelJS.Worksheet {
  return wb.addWorksheet(sheetName.slice(0, 31) || 'Datos', {
    views: [{ showGridLines: false }],
    properties: { defaultRowHeight: 18 }
  });
}

function newWorkbook(): ExcelJS.Workbook {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Zempac Analitika';
  wb.company = 'Zempac Analitika';
  wb.created = new Date();
  return wb;
}

/** Landscape, fit-to-width, repeat the header row on every printed page. */
function applyPrintSetup(ws: ExcelJS.Worksheet, headerRowNumber: number): void {
  ws.pageSetup = {
    orientation: 'landscape',
    fitToPage: true,
    fitToWidth: 1,
    fitToHeight: 0,
    horizontalCentered: false,
    margins: { left: 0.4, right: 0.4, top: 0.5, bottom: 0.5, header: 0.3, footer: 0.3 }
  };
  ws.pageSetup.printTitlesRow = `${headerRowNumber}:${headerRowNumber}`;
}

async function triggerDownload(wb: ExcelJS.Workbook, fileName: string): Promise<void> {
  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName.endsWith('.xlsx') ? fileName : `${fileName}.xlsx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// ─── Standard columnar report ───────────────────────────────────────────────

export async function downloadReport(config: ReportConfig): Promise<void> {
  if (!config.rows || config.rows.length === 0) return;
  const { columns, rows } = config;
  const colCount = columns.length;
  const accent = config.accent ?? BRAND.primary;

  const wb = newWorkbook();
  const ws = newSheet(wb, config.sheetName);

  // Widths grow to fit the (uppercased) header so labels never truncate.
  ws.columns = columns.map(c => ({
    width: Math.max(c.width ?? defaultWidth(c.type ?? 'text'), c.header.length + 3)
  }));

  addChrome(wb, ws, { title: config.title, subtitle: config.subtitle, meta: config.meta, colCount, accent });

  // Header row — light, website-style: uppercase muted labels + accent rule.
  const headerRow = ws.addRow(columns.map(c => c.header.toUpperCase()));
  headerRow.height = 26;
  headerRow.eachCell({ includeEmpty: true }, (cell, col) => {
    const c = columns[col - 1];
    const type = c.type ?? 'text';
    cell.font = { name: FONT, size: 9.5, bold: true, color: { argb: BRAND.inkVariant } };
    cell.fill = fill(BRAND.surfaceLow);
    cell.alignment = { vertical: 'middle', horizontal: c.align ?? defaultAlign(type), indent: 1, wrapText: false };
    cell.border = { top: THIN_BORDER, bottom: { style: 'medium', color: { argb: accent } } };
  });

  // Freeze the branding + header so it stays put while scrolling.
  ws.views = [{ state: 'frozen', ySplit: headerRow.number, showGridLines: false }];

  // Data rows — airy, horizontal separators only, subtle banding.
  rows.forEach((row, i) => {
    const dataRow = ws.addRow(columns.map(c => cellValue(row[c.key], c.type ?? 'text')));
    dataRow.height = 22;
    const banded = i % 2 === 1;
    dataRow.eachCell({ includeEmpty: true }, (cell, col) => {
      const c = columns[col - 1];
      const type = c.type ?? 'text';
      cell.font = { name: FONT, size: 10, color: { argb: BRAND.ink } };
      if (banded) cell.fill = fill(BRAND.surfaceLow);
      cell.alignment = { vertical: 'middle', horizontal: c.align ?? defaultAlign(type), indent: 1 };
      const fmt = numFmtFor(type);
      if (fmt) cell.numFmt = fmt;
      cell.border = { bottom: THIN_BORDER };
    });
  });

  // Totals row — brand-tinted band under a primary rule. A blank spacer row
  // sits between the data and the total so Excel's Filter/Sort (which acts on
  // the contiguous block) treats the total as outside the table and never
  // reorders it along with the rows.
  const hasTotals = columns.some(c => c.total);
  if ((config.showTotals ?? hasTotals) && hasTotals) {
    ws.addRow([]).height = 8;
    const firstTotalIdx = columns.findIndex(c => c.total) + 1; // 1-based
    const totalsRow = ws.addRow(
      columns.map(c => {
        if (c.total) {
          const sum = rows.reduce((s, r) => s + (Number(r[c.key]) || 0), 0);
          return (c.type ?? 'text') === 'percent' ? sum / 100 : sum;
        }
        return '';
      })
    );
    totalsRow.height = 24;
    totalsRow.eachCell({ includeEmpty: true }, (cell, col) => {
      const c = columns[col - 1];
      const type = c.type ?? 'text';
      cell.font = { name: FONT, size: 10.5, bold: true, color: { argb: BRAND.ink } };
      cell.fill = fill(BRAND.headerTint);
      cell.alignment = { vertical: 'middle', horizontal: c.align ?? defaultAlign(type), indent: 1 };
      const fmt = numFmtFor(type);
      if (c.total && fmt) cell.numFmt = fmt;
      cell.border = { top: { style: 'medium', color: { argb: accent } } };
    });
    // Label spans the leading descriptive columns so it never clips, no matter
    // how narrow the first column is; numeric totals stay under their columns.
    if (!columns[0].total) {
      const labelCell = ws.getCell(totalsRow.number, 1);
      labelCell.value = config.totalsLabel ?? 'TOTAL';
      labelCell.alignment = { vertical: 'middle', horizontal: 'left', indent: 1 };
      if (firstTotalIdx > 2) ws.mergeCells(totalsRow.number, 1, totalsRow.number, firstTotalIdx - 1);
    }
  }

  addFooter(ws, colCount);
  applyPrintSetup(ws, headerRow.number);
  await triggerDownload(wb, config.fileName);
}

// ─── Cuadre de Caja receipt ─────────────────────────────────────────────────

export async function downloadReceipt(config: ReceiptConfig): Promise<void> {
  if (!config.lines || config.lines.length === 0) return;
  const colCount = 3;
  const accent = config.accent ?? BRAND.primary;

  const wb = newWorkbook();
  const ws = newSheet(wb, config.sheetName);
  ws.columns = [{ width: 48 }, { width: 14 }, { width: 20 }];

  addChrome(wb, ws, { title: config.title, subtitle: config.subtitle, meta: config.meta, colCount, accent });

  // Header row — matches the columnar report's light header.
  const headerRow = ws.addRow(['DESCRIPCIÓN', 'CANTIDAD', 'VALOR']);
  headerRow.height = 26;
  headerRow.eachCell({ includeEmpty: true }, (cell, col) => {
    cell.font = { name: FONT, size: 9.5, bold: true, color: { argb: BRAND.inkVariant } };
    cell.fill = fill(BRAND.surfaceLow);
    cell.alignment = { vertical: 'middle', horizontal: col === 1 ? 'left' : 'right', indent: 1 };
    cell.border = { top: THIN_BORDER, bottom: { style: 'medium', color: { argb: accent } } };
  });
  ws.views = [{ state: 'frozen', ySplit: headerRow.number, showGridLines: false }];

  for (const line of config.lines) {
    if (line.kind === 'header') {
      const r = ws.addRow([line.descripcion, '', '']);
      r.height = 24;
      ws.mergeCells(r.number, 1, r.number, colCount);
      const c = ws.getCell(r.number, 1);
      c.value = line.descripcion.toUpperCase();
      c.font = { name: FONT, size: 10, bold: true, color: { argb: accent } };
      c.fill = fill(BRAND.headerTint);
      c.alignment = { vertical: 'middle', horizontal: 'left', indent: 1 };
      continue;
    }

    const isTotal = line.kind === 'total';
    const isSub = line.kind === 'subitem';
    const r = ws.addRow([
      line.descripcion,
      line.cantidad != null ? Math.trunc(line.cantidad) : '',
      line.valor != null ? line.valor : ''
    ]);
    r.height = 22;

    const descCell = ws.getCell(r.number, 1);
    descCell.font = { name: FONT, size: 10, bold: isTotal, color: { argb: isSub ? BRAND.inkVariant : BRAND.ink } };
    descCell.alignment = { vertical: 'middle', horizontal: 'left', indent: isSub ? 3 : 1 };

    const qtyCell = ws.getCell(r.number, 2);
    qtyCell.font = { name: FONT, size: 10, color: { argb: BRAND.inkVariant } };
    qtyCell.alignment = { vertical: 'middle', horizontal: 'right', indent: 1 };
    qtyCell.numFmt = numFmtFor('int')!;

    const valCell = ws.getCell(r.number, 3);
    valCell.font = { name: FONT, size: 10, bold: isTotal, color: { argb: BRAND.ink } };
    valCell.alignment = { vertical: 'middle', horizontal: 'right', indent: 1 };
    valCell.numFmt = numFmtFor('money')!;

    for (let col = 1; col <= colCount; col++) {
      const cell = ws.getCell(r.number, col);
      if (isTotal) {
        cell.fill = fill(BRAND.headerTint);
        cell.border = { top: { style: 'medium', color: { argb: accent } } };
      } else {
        cell.border = { bottom: THIN_BORDER };
      }
    }
  }

  addFooter(ws, colCount);
  applyPrintSetup(ws, headerRow.number);
  await triggerDownload(wb, config.fileName);
}
