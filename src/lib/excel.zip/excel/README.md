# Zempac Analitika — Excel Reports Module

This folder generates the **premium, branded Excel (`.xlsx`) exports** for every
report in the dashboard. It is self-contained: the whole `src/lib/excel/` folder
can be lifted out and used as the reference spec for re-implementing the exports
**on the backend** (so a report can be downloaded *or* emailed from the server).

The goal is that a downloaded workbook feels like the same product as the web app:
same palette, same typography hierarchy, same "letterhead" identity — but native
to Excel (real number formats, sortable/filterable data, print-ready).

> **Where this is going:** Excel generation is moving to the backend so the server
> can both stream the file for download and attach it to emails. This document is
> the contract: the layout, the theme tokens, the number formats and the behaviors
> below must be reproduced exactly, in whatever library the backend uses
> (e.g. **EPPlus** or **ClosedXML** for .NET, Apache POI for Java, etc.). The
> TypeScript here is the working reference implementation.

---

## 1. Folder structure

```
src/lib/excel/
├── index.ts        Public surface: re-exports the builder + types + fileNameSafe()
├── theme.ts        Design tokens: palette (ARGB), font, number formats, widths
├── logo.ts         Zempac logo embedded as base64 (from public/zempac-logo.png)
├── builder.ts      The engine: downloadReport() + downloadReceipt() + shared chrome
├── reports/        One file per report — declares columns/labels only (no styling)
│   ├── ventas-producto-marca.ts
│   ├── productos.ts
│   ├── ventas-facturador.ts
│   ├── productos-negativos.ts
│   ├── ventas.ts                (sucursal summary + daily detail)
│   ├── devoluciones.ts          (sucursal summary + daily detail)
│   ├── cuentas-por-cobrar.ts
│   └── cuadre-caja.ts           (receipt + productos-por-lote table)
└── README.md       This document
```

**Separation of concerns (important):**

- `theme.ts` + `builder.ts` = **how a report looks**. The single source of truth.
  Change a color, font size or behavior here and *every* report moves together.
- `reports/*.ts` = **what a report contains**. Each file only declares its columns
  (key, header, type, totals) and maps domain data → rows. It never sets a color,
  font or border. This makes visual drift between reports impossible.

A page (`src/app/dashboard/<report>/page.tsx`) imports its report function, renders
the shared `ExcelExportButton`, and calls the function with the on-screen data +
some context (`meta`).

---

## 2. Design tokens (`theme.ts`)

All colors are **ARGB** strings (`AA RR GG BB`, no `#`). They mirror the web tokens
in `tailwind.config.ts` (Lumina Vision Light).

| Token         | ARGB         | Hex        | Use |
|---------------|--------------|------------|-----|
| `primary`     | `FF0040DF`   | `#0040DF`  | Accent: header underline, wordmark, meta values, totals rule |
| `primarySoft` | `FF2D5BFF`   | `#2D5BFF`  | (reserved) |
| `ink`         | `FF191C1D`   | `#191C1D`  | Title, data text |
| `inkVariant`  | `FF434656`   | `#434656`  | Subtitle, header labels |
| `outline`     | `FF747688`   | `#747688`  | Meta labels, footer |
| `white`       | `FFFFFFFF`   | `#FFFFFF`  | — |
| `surfaceLow`  | `FFF3F4F5`   | `#F3F4F5`  | Header fill, zebra banding on odd rows |
| `surfaceMid`  | `FFEDEEEF`   | `#EDEEEF`  | Thin grid borders |
| `surfaceHigh` | `FFE7E8E9`   | `#E7E8E9`  | (reserved) |
| `headerTint`  | `FFEAF0FF`   | `#EAF0FF`  | Totals band, receipt section headers |
| `positive`    | `FF137333`   | `#137333`  | (reserved) |
| `negative`    | `FFC5221F`   | `#C5221F`  | (reserved; money negatives use the `[Red]` format instead) |
| `tertiary`    | `FF993100`   | `#993100`  | (reserved) |

**Font:** `Calibri` everywhere. Manrope (the web font) isn't installed in Excel;
Calibri ships with every Excel and keeps the clean geometric feel.

**Number formats** (Excel format codes):

| Type      | Format code                          | Notes |
|-----------|--------------------------------------|-------|
| `money`   | `"$"#,##0.00;[Red]-"$"#,##0.00`      | Negatives auto-render red, matching the web `-$…` |
| `int`     | `#,##0`                              | |
| `decimal` | `#,##0.00`                          | |
| `percent` | `0.00%`                             | **Value is stored as a ratio** — see §5 |
| `date`    | `dd/mm/yyyy`                        | Cell holds a real Excel date when parseable |

**Column widths** (characters). Effective width = `max(declared ?? default, header.length + 3)`
so a header label can never truncate.

| Type      | Default width |
|-----------|---------------|
| `money`   | 16 |
| `percent` | 12 |
| `int` / `decimal` | 12 |
| `date`    | 14 |
| `text`    | 24 |

**Borders:** `THIN_BORDER` = thin, color `surfaceMid`. The table uses **horizontal
separators only** (no vertical grid lines) to match the web's `divide-y` look.

---

## 3. Report anatomy (the "letterhead")

Every sheet is laid out top-to-bottom exactly like this. Row heights are in points.

```
┌───────────────────────────────────────────────────────────────────────┐
│ [logo]  Zempac Analitika                        ← wordmark eyebrow      │  (1) h21
│ Cuentas por Cobrar                              ← title                 │  (2) h30
│ Clientes con saldo pendiente y antigüedad       ← subtitle              │  (3) h17
│                                                                          │  (4) h4  spacer
│ SALDO TOTAL CARTERA $114,463,329.31   CLIENTES CON SALDO 512   …         │  (5) h20 meta
│                                                                          │  (6) h10 spacer
│ #  CÓDIGO  CLIENTE      SALDO TOTAL  …           ← header (frozen)       │  (7) h26
│ 1  611651  ARS SENASA …  $23,163,798.79 …        ← data rows (banded)    │  (8+) h22
│ …                                                                        │
│                                                  ← blank spacer          │      h8
│ TOTAL (TOP 10)           $59,057,436.41 …        ← totals band           │      h24
│                                                                          │      h8  spacer
│ Documento generado automáticamente · Zempac Analitika · <fecha/hora>     │      footer (italic)
└───────────────────────────────────────────────────────────────────────┘
```

Exact styling of each band:

- **Logo:** `logo.ts` base64 PNG, drawn 22×22 px, anchored at column `0.08`,
  row `(wordmarkRow − 1) + 0.12` (top-left, over the wordmark row). Forms an
  inline lockup with the wordmark.
- **Wordmark** (row 1): merged full width. `Calibri 12 bold`, color `primary`,
  left-aligned, `indent 4` (clears the logo).
- **Title** (row 2): merged. `Calibri 20 bold`, color `ink`, left.
- **Subtitle** (row 3): merged. `Calibri 10.5`, color `inkVariant`, left.
- **Meta strip** (row 5): merged, one line of rich-text runs. Each item =
  `LABEL` (`Calibri 9.5 bold`, `outline`, uppercase, 3 trailing spaces) +
  `value` (`Calibri 12.5 bold`, `primary`). Items separated by 10 spaces.
  Values are large + brand-blue so they read like the dashboard's KPI numbers.
- **Header row** (frozen): `Calibri 9.5 bold`, color `inkVariant`, fill
  `surfaceLow`, header text **UPPERCASE**, `indent 1`, alignment per column type.
  Border: top thin `surfaceMid`, **bottom `medium` `primary`** (the accent rule).
  The pane is frozen through this row; **no AutoFilter** is applied by us.
- **Data rows:** `Calibri 10`, color `ink`, `indent 1`, alignment per type,
  per-type number format, bottom border thin `surfaceMid`. Odd rows filled
  `surfaceLow` (zebra banding).
- **Totals band:** preceded by a **blank spacer row** (see §4). `Calibri 10.5
  bold`, color `ink`, fill `headerTint`, top border `medium` `primary`. Only the
  columns flagged `total` show a sum; the label spans the leading descriptive
  columns (see §4).
- **Footer:** merged. `Calibri 9 italic`, color `outline`:
  `Documento generado automáticamente · Zempac Analitika · <es-HN long date + time>`.
- **Print setup:** landscape, fit-to-width = 1 page, fit-to-height = 0 (unbounded),
  margins `{L .4, R .4, T .5, B .5, header .3, footer .3}`, and the header row is
  set as a **repeating print title** so it prints on every page.

Default **alignment** by type: `text` → left, `date` → center, numeric → right.

---

## 4. Behaviors that make it "premium" (must reproduce)

1. **Auto-fit widths** — a column is at least `header.length + 3` wide, so labels
   like "Días Máx. Atraso" never truncate.
2. **Totals never clip** — the totals label (`TOTAL`, or a custom `totalsLabel`)
   is placed in column 1 and **merged across the leading non-total columns**
   (columns `1 … firstTotalColumn−1`, when there are ≥2 of them). Numeric totals
   stay under their own columns.
3. **Totals excluded from sort/filter** — a **blank row sits between the last data
   row and the totals row**. Excel's built-in *Data → Filter* / *Sort* acts on the
   contiguous block; the blank row terminates that block, so the total is never
   reordered along with the data. (This is the standard fix — reproduce it.)
4. **Money negatives are red** via the format code, not manual coloring.
5. **Percent stored as a ratio** — see §5.
6. **Dates are real Excel dates** when the source parses; otherwise the raw string.
7. **Freeze panes** through the header row so it stays visible while scrolling.
8. **No AutoFilter** — the dashboards don't show filter chrome; we keep it clean.
   (The user can still add a filter manually; behavior 3 keeps the total safe.)
9. **Print-ready** — landscape, fit-to-width, repeating header (see §3).

### Data completeness rule (critical for the backend)

**An export must contain the entire dataset, never a single paginated page.**
If a report is server-paginated, fetch/stream **all** pages before writing the
workbook. Today only **Productos Negativos** is paginated; its frontend export
loops `pagina = 1 … totalPaginas` and concatenates before building the file. On
the backend this is even simpler — run the query without paging (or loop all
pages) and feed the full result set to the writer.

---

## 5. Value coercion rules (`cellValue`)

Given a raw value and a column `type`, the cell value stored is:

| Type      | Stored value |
|-----------|--------------|
| `text`    | `String(value)` (or `''` when null) |
| `date`    | a real `Date` when `new Date(value)` is valid, else the raw string, else `''` |
| `money` / `int` / `decimal` | the number (non-finite → `0`) |
| `percent` | **`number / 100`** — inputs arrive as `0–100` (e.g. `32.5`) and are stored as the ratio `0.325`, which the `0.00%` format renders as `32.50%` |

Totals sum the **raw** numbers; for `percent` totals the sum is likewise `/100`.

---

## 6. Public API (`builder.ts`)

Two entry points. Both are `async` and, in this frontend build, end by triggering a
browser download (`Blob` + `<a download>`). **On the backend, replace only that last
step** — return the `.xlsx` bytes to stream or email; everything above it is identical.

### `downloadReport(config: ReportConfig)` — a columnar table

```ts
interface ReportColumn {
  header: string;              // shown UPPERCASE in the header row
  key: string;                 // key read from each row object
  type?: 'text'|'money'|'int'|'decimal'|'percent'|'date';  // default 'text'
  width?: number;              // chars; grown to fit the header
  total?: boolean;             // sum this column in the totals row
  align?: 'left'|'center'|'right';  // overrides the per-type default
}
interface ReportMetaItem { label: string; value: string; }
interface ReportConfig {
  title: string;
  subtitle?: string;
  fileName: string;            // '.xlsx' appended if missing
  sheetName: string;           // truncated to 31 chars (Excel limit)
  columns: ReportColumn[];
  rows: Array<Record<string, unknown>>;
  meta?: ReportMetaItem[];     // the headline strip (period, sucursal, KPIs…)
  showTotals?: boolean;        // default: true when any column has `total`
  totalsLabel?: string;        // default 'TOTAL'
  accent?: string;             // ARGB; default brand primary
}
```

### `downloadReceipt(config: ReceiptConfig)` — the Cuadre de Caja receipt

A cuadre is a formatted receipt (section headers, sub-items, totals), not a uniform
table, so it has its own writer with 3 fixed columns (`Descripción`, `Cantidad`,
`Valor`; widths `48 / 14 / 20`) but the **same chrome** (logo/title/subtitle/meta/footer).

```ts
type ReceiptLineKind = 'header' | 'item' | 'subitem' | 'total';
interface ReceiptLine {
  descripcion: string;
  cantidad?: number | null;
  valor?: number | null;
  kind: ReceiptLineKind;
}
interface ReceiptConfig {
  title: string; subtitle?: string; fileName: string; sheetName: string;
  meta?: ReportMetaItem[];
  lines: ReceiptLine[];
  accent?: string;
}
```

Receipt line rendering:

| Kind      | Rendering |
|-----------|-----------|
| `header`  | merged across 3 cols, UPPERCASE, `Calibri 10 bold` `primary`, fill `headerTint` |
| `item`    | `descripcion` left (`indent 1`, `ink`), `cantidad` right (int), `valor` right (money) |
| `subitem` | as `item` but `descripcion` `indent 3`, color `inkVariant` |
| `total`   | bold, fill `headerTint`, top border `medium` `primary` |

Non-total rows get a bottom thin `surfaceMid` border.

---

## 7. Adding a new report

1. **Create** `src/lib/excel/reports/<slug>.ts`.
2. **Declare `COLUMNS: ReportColumn[]`** — pick a `type` per column, set `total: true`
   where a sum makes sense, widen `text` columns as needed. Order columns
   descriptive-first (text/date/rank), then the numeric columns; this keeps the
   merged totals label clean.
3. **Export a function** that maps your domain rows to plain objects keyed by the
   column `key`s and calls `downloadReport({ … })`. Keep all styling out of this
   file — only columns, labels, `title/subtitle/fileName/sheetName`, `meta`, and
   optionally `totalsLabel`/`accent`.
4. **Wire the page** (`src/app/dashboard/<slug>/page.tsx`): import the function,
   render `<ExcelExportButton onClick={handleExport} …/>` (from
   `@/components/common`), and in `handleExport` call it with the on-screen data
   plus `meta` context (período, sucursal, KPIs).
5. **If the data is paginated, fetch every page first** and pass the full set
   (see §4 and the Productos Negativos handler).

Example (abridged):

```ts
// src/lib/excel/reports/mi-reporte.ts
import { downloadReport, type ReportColumn, type ReportMetaItem } from '../builder';
import type { RptMiFila } from '@/lib/types';

const COLUMNS: ReportColumn[] = [
  { header: 'Sucursal', key: 'sucursal', type: 'text', width: 28 },
  { header: 'Total',    key: 'total',    type: 'money', total: true },
];

export function exportMiReporte(rows: RptMiFila[], meta?: ReportMetaItem[]) {
  return downloadReport({
    title: 'Mi Reporte',
    subtitle: 'Descripción corta',
    fileName: 'mi-reporte',
    sheetName: 'Mi Reporte',
    meta,
    columns: COLUMNS,
    rows: rows.map(r => ({ sucursal: r.sucursal ?? '', total: r.total ?? 0 })),
  });
}
```

For a report with a **grand total that differs from the rows shown** (e.g. a "top N"
list where the header carries a portfolio-wide total), keep the true total in `meta`,
add a `Mostrando: Top N` meta item, and set `totalsLabel: 'TOTAL (TOP N)'` — but only
when it's actually a subset. See `cuentas-por-cobrar.ts` for the pattern.

---

## 8. Report catalog

| Report file | Sheet | Totals | Notes |
|-------------|-------|--------|-------|
| `ventas-producto-marca.ts` | Ventas por Marca | Cantidad, Total | meta: período, marca |
| `productos.ts` | Más Vendidos | Cantidad, Total, Costo, Margen, Facturas | ranking with `#` |
| `ventas-facturador.ts` | Por Facturador | Facturas, Total | `% del Total` computed |
| `productos-negativos.ts` | Productos Negativos | Existencia | **paginated → export loops all pages** |
| `ventas.ts` | Ventas por Sucursal · Ventas Diarias | most money cols + Facturas | list summary + per-sucursal daily |
| `devoluciones.ts` | Devoluciones · Devoluciones Diarias | most money cols + Cantidad | list summary + per-sucursal daily |
| `cuentas-por-cobrar.ts` | Cuentas por Cobrar | Saldo, Corriente, Vencido, Facturas | portfolio total in meta; `TOTAL (TOP N)` when subset |
| `cuadre-caja.ts` | Cuadre de Caja / Cuadre Lote / Productos por lote | receipt totals + Vendido | `downloadReceipt` for the two receipts, `downloadReport` for the product table |

---

## 9. Backend re-implementation checklist

Porting to a server library (EPPlus / ClosedXML / POI / …):

- [ ] Recreate the **palette** (§2) and **number format codes** exactly. Percent is
      a **ratio** with `0.00%`; money uses the two-part red-negative code.
- [ ] Reproduce the **letterhead layout** and per-band styling (§3), including the
      embedded logo (base64 in `logo.ts`, or ship the PNG), row heights and merges.
- [ ] Implement the **four behaviors** in §4 that are easy to miss: header auto-fit,
      totals-label merge, **blank row before the totals**, and freeze panes.
- [ ] Keep **percent-as-ratio**, **real dates**, and **red-negative money**.
- [ ] Apply **landscape / fit-to-width / repeat-header** print setup.
- [ ] **Export the full dataset** — never a single page (§4).
- [ ] Replace only the final "download" step with "return bytes / stream / email".
      Everything that builds the workbook is identical.
- [ ] Sheet names are capped at 31 chars and must not contain `: \ / ? * [ ]`.

The TypeScript in this folder is the authoritative reference for any ambiguity.
