// Premium Excel theme for Zempac Analitika report exports. Colors mirror the
// web design tokens (tailwind.config.ts · Lumina Vision Light) so a downloaded
// workbook feels like the same product. ExcelJS wants ARGB hex (no leading #).

/** Brand palette as ARGB strings, taken 1:1 from the web tokens. */
export const BRAND = {
  primary: 'FF0040DF',        // primary.DEFAULT
  primarySoft: 'FF2D5BFF',    // primary.container
  ink: 'FF191C1D',            // ink.DEFAULT
  inkVariant: 'FF434656',     // ink.variant
  outline: 'FF747688',        // outline.DEFAULT
  white: 'FFFFFFFF',          // surface.lowest
  surfaceLow: 'FFF3F4F5',     // surface.low  (row banding)
  surfaceMid: 'FFEDEEEF',     // surface.mid  (borders)
  surfaceHigh: 'FFE7E8E9',    // surface.high (totals band)
  headerTint: 'FFEAF0FF',     // faint primary tint for meta labels / totals accents
  positive: 'FF137333',       // positive.fg
  negative: 'FFC5221F',       // negative.fg
  tertiary: 'FF993100'        // tertiary.DEFAULT
} as const;

/**
 * A cross-platform premium sans. Manrope (the web font) isn't installed in
 * Excel, so we fall back to Calibri which every Excel ships with and which
 * keeps the clean, geometric feel.
 */
export const FONT = 'Calibri';

/** Number formats. Money shows negatives in red, matching fmtMoney's "-$…". */
export const NUMFMT = {
  money: '"$"#,##0.00;[Red]-"$"#,##0.00',
  int: '#,##0',
  decimal: '#,##0.00',
  percent: '0.00%',
  date: 'dd/mm/yyyy'
} as const;

/** Thin border in the token border color, used for the table grid. */
export const THIN_BORDER = {
  style: 'thin' as const,
  color: { argb: BRAND.surfaceMid }
};

/** Column kinds a report can declare; drives alignment + number format. */
export type ColumnType = 'text' | 'money' | 'int' | 'decimal' | 'percent' | 'date';

export function numFmtFor(type: ColumnType): string | undefined {
  switch (type) {
    case 'money':
      return NUMFMT.money;
    case 'int':
      return NUMFMT.int;
    case 'decimal':
      return NUMFMT.decimal;
    case 'percent':
      return NUMFMT.percent;
    case 'date':
      return NUMFMT.date;
    default:
      return undefined;
  }
}

export function defaultAlign(type: ColumnType): 'left' | 'center' | 'right' {
  return type === 'text' ? 'left' : type === 'date' ? 'center' : 'right';
}

/** Sensible default column width (chars) when a report doesn't specify one. */
export function defaultWidth(type: ColumnType): number {
  switch (type) {
    case 'money':
      return 16;
    case 'percent':
      return 12;
    case 'int':
    case 'decimal':
      return 12;
    case 'date':
      return 14;
    default:
      return 24;
  }
}
